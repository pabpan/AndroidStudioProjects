package com.example.sumar;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class pantalla2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla2);

     final TextView suma = (TextView) findViewById(R.id.sumar_numeros);
     Bundle miBundleRecoger = getIntent().getExtras();
     suma.setText(miBundleRecoger.getString("TEXTO"));
    }
}